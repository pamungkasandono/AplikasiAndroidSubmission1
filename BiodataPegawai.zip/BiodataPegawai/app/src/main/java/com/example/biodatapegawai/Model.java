package com.example.biodatapegawai;

public class Model {
    private int id;
    private String nama;
    private String nip;
    private String nik;
    private byte[] image;

    public Model(int id, String nama, String nip, String nik, byte[] image) {
        this.id = id;
        this.nama = nama;
        this.nip = nip;
        this.nik = nik;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId() {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama() {
        this.nama = nama;
    }

    public String getNip() {
        return nip;
    }

    public void setNip() {
        this.nip = nip;
    }

    public String getNik() {
        return nik;
    }

    public void setNik() {
        this.nik = nik;
    }

    public  byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
}

