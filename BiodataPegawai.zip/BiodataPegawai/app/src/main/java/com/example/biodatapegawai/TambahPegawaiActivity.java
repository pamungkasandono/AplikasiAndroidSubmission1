package com.example.biodatapegawai;

import android.Manifest;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import android.os.Bundle;

import java.io.ByteArrayOutputStream;

public class TambahPegawaiActivity extends AppCompatActivity {


    protected  Cursor cursor;
    String gender;
    final int REQUEST_CODE_GALLERY  = 999;
    EditText text1, text2, text3, text5, text6, text7, text8, text9, text10, text11;
    TextView title;
    Button fabCreate;
    FrameLayout btnKembali;
    RadioGroup radioGender;
    RadioButton radioMale, radioFemale;
    ImageView imageView;
    SQLiteHelper sqLiteHelper;
//    ExtendedFloatingActionButton fabCreate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_pegawai);

//        Toolbar toolbar = findViewById(R.id.toolbar);
//        toolbar.setTitle("Buat Biodata");
//        setSupportActionBar(toolbar);
//        assert getSupportActionBar() != null;
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        title = findViewById(R.id.toolbar);
        title.setText("Tambah Data Pegawai");

        sqLiteHelper = new SQLiteHelper(this);
        text1 = findViewById(R.id.editText1);
        text2 = findViewById(R.id.editText2);
        text3 = findViewById(R.id.editText3);
        text5 = findViewById(R.id.editText5);
        radioMale = findViewById(R.id.radioMale);
        radioFemale = findViewById(R.id.radioFemale);
        text6 = findViewById(R.id.editText6);
        text7 = findViewById(R.id.editText7);
        text8 = findViewById(R.id.editText8);
        text9 = findViewById(R.id.editText9);
        text10 = findViewById(R.id.editText10);
        text11 = findViewById(R.id.editText11);
        imageView = findViewById(R.id.imageView);
        fabCreate = findViewById(R.id.fabCreate);
        btnKembali = findViewById(R.id.fl1);

        btnKembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                onBackPressed(); // or super.finish();
                finish();
            }
        });

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //read external storage permission to select image from gallery
                //runtime permission for devices android 6.0 and above
                ActivityCompat.requestPermissions(
                        TambahPegawaiActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        REQUEST_CODE_GALLERY
                );
            }
        });

        fabCreate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View arg0) {
                if (radioMale.isChecked()){
                    gender = radioMale.getText().toString();
                }
                else if (radioFemale.isChecked()){
                    gender = radioFemale.getText().toString();
                }
                try {
                    sqLiteHelper.insertData(
                            text1.getText().toString(),
                            text2.getText().toString(),
                            text3.getText().toString(),
                            gender,
                            text5.getText().toString(),
                            text6.getText().toString(),
                            text7.getText().toString(),
                            text8.getText().toString(),
                            text9.getText().toString(),
                            text10.getText().toString(),
                            text11.getText().toString(),
                            imageViewToByte(imageView)
                    );
                    Toast.makeText(getApplicationContext(), "Berhasil", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(TambahPegawaiActivity.this, MainActivity.class));
                    finish();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static byte[] imageViewToByte(ImageView image) {
        Bitmap bitmap = ((BitmapDrawable)image.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CODE_GALLERY){
            if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                //gallery intent
                Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent, REQUEST_CODE_GALLERY);
            }
            else {
                Toast.makeText(this, "Don't have permission to access file location", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK){
            Uri imageUri = data.getData();
            CropImage.activity(imageUri)
                    .setGuidelines(CropImageView.Guidelines.ON) //enable image guidlines
                    .setAspectRatio(1,1)// image will be square
                    .start(this);
        }
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult result =CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK){
                Uri resultUri = result.getUri();
                //set image choosed from gallery to image view
                imageView.setImageURI(resultUri);
            }
            else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                Exception error = result.getError();
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }
}