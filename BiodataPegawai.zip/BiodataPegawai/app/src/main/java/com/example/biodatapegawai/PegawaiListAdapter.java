package com.example.biodatapegawai;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class PegawaiListAdapter extends BaseAdapter{
    private Context context;
    private int layout;
    private ArrayList<Model> pegawaiList;

    public PegawaiListAdapter(Context context, int layout, ArrayList<Model> pegawaiList){
        this.context = context;
        this.layout = layout;
        this.pegawaiList = pegawaiList;
    }

    @Override
    public int getCount() {
        return pegawaiList.size();
    }

    @Override
    public Object getItem(int i) {
        return pegawaiList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    public class ViewHolder {
        ImageView imageView;
        TextView txtNama, txtNip, txtNik;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View row = view;
        ViewHolder holder = new ViewHolder();

        if(row == null) {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layout, null);
            holder.txtNama = row.findViewById(R.id.txtNama);
            holder.txtNip = row.findViewById(R.id.txtNip);
            holder.txtNik = row.findViewById(R.id.txtNik);
            holder.imageView = row.findViewById(R.id.imgIcon);
            row.setTag(holder);
        }
        else {
            holder = (ViewHolder)row.getTag();
        }
        Model model = pegawaiList.get(i);

        holder.txtNama.setText(model.getNama());
        holder.txtNip.setText(model.getNip());
        holder.txtNik.setText(model.getNik());

        byte[] pegawaiImage = model.getImage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(pegawaiImage, 0, pegawaiImage.length);
        holder.imageView.setImageBitmap(bitmap);

        return row;
    }
}
