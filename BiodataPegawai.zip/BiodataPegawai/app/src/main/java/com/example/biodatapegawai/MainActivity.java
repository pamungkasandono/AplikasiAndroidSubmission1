package com.example.biodatapegawai;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView mListView;
    protected Cursor cursor;
    SQLiteHelper sqliteHelper;
    ArrayList<Model> mList;
    PegawaiListAdapter mAdapter = null;
    FrameLayout btnAdd;

    ImageView imageViewIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView toolbar = findViewById(R.id.toolbar);
        toolbar.setText("Aplikasi Biodata Pegawai");
//        setSupportActionBar(toolbar);

        mListView = findViewById(R.id.listView);
        mList = new ArrayList<>();
        mAdapter = new PegawaiListAdapter(this, R.layout.row, mList);
        mListView.setAdapter(mAdapter);
        sqliteHelper = new SQLiteHelper(this);

        btnAdd = findViewById(R.id.btnTambah);
        Log.d("btn", String.valueOf(btnAdd));
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, TambahPegawaiActivity.class));
                Log.d("btn", "test");
            }
        });
//        btnAdd.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(MainActivity.this, TambahPegawaiActivity.class);
//                startActivity(intent);
//            }
//        });

        SQLiteDatabase sqliteDatabase = sqliteHelper.getReadableDatabase();
        cursor = sqliteDatabase.rawQuery("SELECT * FROM tb_pegawai", null);
        mList.clear();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String nama = cursor.getString(1);
            String nip = cursor.getString(2);
            String nik = cursor.getString(10);
            byte[] image = cursor.getBlob(12);
            mList.add(new Model(id, nama, nip, nik, image));
        }
        mAdapter.notifyDataSetChanged();
        if (mList.size() == 0) {
            Toast.makeText(this, "No record found...", Toast.LENGTH_SHORT).show();
        }
        cursor.close();

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(getApplicationContext(), DetailPegawaiActivity.class);
                i.putExtra("id", mList.get(position).getId());
                view.getContext().startActivity(i);
            }
        });
    }
}