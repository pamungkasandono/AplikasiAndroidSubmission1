package com.example.biodatapegawai;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class SQLiteHelper extends SQLiteOpenHelper {
    private static final String db_name = "pegawai.db";
    private static final int db_version = 1;
//    public static final String TABLE_NAME = "tb_pegawai";
//    public static final String COLUMN_ID = "id";
//    public static final String COLUMN_NAMA = "nama";
//    public static final String COLUMN_NIP = "nip";
//    public static final String COLUMN_TTL = "ttl";
//    public static final String COLUMN_KELAMIN = "jenis_kelamin";
//    public static final String COLUMN_JABATAN = "jabatan";
//    public static final String COLUMN_ALAMAT_KANTOR = "alamat_kantor";
//    public static final String COLLUMN_ALAMAT_RUMAH =  "alamat_rumah";
//    public static final String COLUMN_NPWP = "npwp";
//    public static final String COLUMN_KAPREG = "kapreg";
//    public static final String COLUMN_NIK = "nik";
//    public static final String COLUMN_REKENING = "rekening";
//    public static final String COLUMN_FOTO = "foto";
//    public static final String db_name = "pegawai.db";
//    public static final int db_version = 1;
//
//    private static final String db_create = "CREATE TABLE IF NOT EXISTS "
//            + TABLE_NAME + "("
//            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
//            + COLUMN_NAMA + " VARCHAR, "
//            + COLUMN_NIP + " VARCHAR, "
//            + COLUMN_TTL + " VARCHAR, "
//            + COLUMN_KELAMIN + " VARCHAR, "
//            + COLUMN_JABATAN + " VARCHAR, "
//            + COLUMN_ALAMAT_KANTOR + " TEXT, "
//            + COLLUMN_ALAMAT_RUMAH + " TEXT, "
//            + COLUMN_NPWP + " VARCHAR, "
//            + COLUMN_KAPREG + " VARCHAR, "
//            + COLUMN_NIK + " VARCHAR,"
//            + COLUMN_REKENING + " VARCHAR, "
//            + COLUMN_FOTO + " BLOB);";

    public SQLiteHelper(Context context) {
        super(context, db_name, null, db_version);
        // Auto generated
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE tb_pegawai(id INTEGER PRIMARY KEY AUTOINCREMENT, nama VARCHAR, nip VARCHAR, ttl VARCHAR, jenis_kelamin VARCHAR, jabatan VARCHAR, alamat_kantor VARCHAR, alamat_rumah VARCHAR, npwp VARCHAR, kapreg VARCHAR, nik VARCHAR, rekening VARCHAR, foto BLOB);";
        Log.d("Data", "onCreate:" + sql);
        db.execSQL(sql);
    }

    public Cursor getData(String sql){
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }

    public void insertData(String nama, String nip, String ttl, String jenis_kelamin, String jabatan, String alamat_kantor, String alamat_rumah, String npwp, String kapreg, String nik, String rekening, byte[] foto){
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT INTO tb_pegawai VALUES(NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();

        statement.bindString(1, nama);
        statement.bindString(2, nip);
        statement.bindString(3, ttl);
        statement.bindString(4, jenis_kelamin);
        statement.bindString(5, jabatan);
        statement.bindString(6, alamat_kantor);
        statement.bindString(7, alamat_rumah);
        statement.bindString(8, npwp);
        statement.bindString(9, kapreg);
        statement.bindString(10, nik);
        statement.bindString(11, rekening);
        statement.bindBlob(12, foto);

        statement.executeInsert();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(SQLiteHelper.class.getName(),"Upgrading database from version " + oldVersion + " to "
                + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS tb_pegawai ");
        onCreate(db);
    }
}
