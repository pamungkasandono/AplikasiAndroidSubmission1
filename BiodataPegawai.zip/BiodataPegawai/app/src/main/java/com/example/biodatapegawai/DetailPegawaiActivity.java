package com.example.biodatapegawai;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class DetailPegawaiActivity extends AppCompatActivity {

    protected Cursor cursor;
    SQLiteHelper sqLiteHelper;
    ImageView imageView;
    TextView text1, text2, text3, text4, text5, text6, text7, text8, text9, text10, text11, text12, toolbar;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_pegawai);

        Toast.makeText(this, "Untuk ke menu, swipe tombol navigasi lalu tekan back", Toast.LENGTH_LONG).show();
        View decorView = getWindow().getDecorView();

        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
                | View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY // hide status bar and nav bar after a short delay, or if the user interacts with the middle of the screen
        );
//        toolbar = findViewById(R.id.toolbar);
//        toolbar.setText("Detail Biodata Pegawai");
//        setSupportActionBar(toolbar);
//        assert getSupportActionBar() != null;
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        sqLiteHelper= new SQLiteHelper(this);
        text1 = findViewById(R.id.textView1);
        text2 = findViewById(R.id.textView2);
        text3 = findViewById(R.id.textView3);
        text4 = findViewById(R.id.textView4);
        text5 = findViewById(R.id.textView5);
        text6 = findViewById(R.id.textView6);
        text7 = findViewById(R.id.textView7);
        text8 = findViewById(R.id.textView8);
        text9 = findViewById(R.id.textView9);
        text10 = findViewById(R.id.textView10);
        text11 = findViewById(R.id.textView11);
        text12 = findViewById(R.id.textView12);
        imageView = findViewById(R.id.imageView);
        SQLiteDatabase db = sqLiteHelper.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM tb_pegawai WHERE id ='" + getIntent().getExtras().getInt("id") + "'", null);
        cursor.moveToFirst();
        if(cursor.getCount() > 0) {
            cursor.moveToPosition(0);
            text1.setText(cursor.getString(1));
            text2.setText(cursor.getString(2));
            text3.setText(cursor.getString(3));
            text4.setText(cursor.getString(4));
            text5.setText(cursor.getString(5));
            text6.setText(cursor.getString(6));
            text7.setText(cursor.getString(7));
            text8.setText(cursor.getString(8));
            text9.setText(cursor.getString(9));
            text10.setText(cursor.getString(10));
            text11.setText(cursor.getString(11));
            text12.setText(cursor.getString(1));
            byte[] image = (cursor.getBlob(12));
            Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
            imageView.setImageBitmap(bitmap);
        }
    }
}